package com.example.bhushan.countryinfoapp;

import java.io.Serializable;

/**
 * Created by bhushan on 4/11/17.
 */

public class CountryParameters implements Serializable {
    private String Countryname,capital,language,borderingcountries;
    private int population,timezone,currencycode;

    public CountryParameters(String countryname, String capital, String language, String borderingcountries, int population, int timezone, int currencycode) {
        Countryname = countryname;
        this.capital = capital;
        this.language = language;
        this.borderingcountries = borderingcountries;
        this.population = population;
        this.timezone = timezone;
        this.currencycode = currencycode;
    }

    public String getCountryname() {
        return Countryname;
    }

    public void setCountryname(String countryname) {
        Countryname = countryname;
    }

    public String getCapital() {
        return capital;
    }

    public void setCapital(String capital) {
        this.capital = capital;
    }

    public String getLanguage() {
        return language;
    }

    public void setLanguage(String language) {
        this.language = language;
    }

    public String getBorderingcountries() {
        return borderingcountries;
    }

    public void setBorderingcountries(String borderingcountries) {
        this.borderingcountries = borderingcountries;
    }

    public int getPopulation() {
        return population;
    }

    public void setPopulation(int population) {
        this.population = population;
    }

    public int getTimezone() {
        return timezone;
    }

    public void setTimezone(int timezone) {
        this.timezone = timezone;
    }

    public int getCurrencycode() {
        return currencycode;
    }

    public void setCurrencycode(int currencycode) {
        this.currencycode = currencycode;
    }
}
