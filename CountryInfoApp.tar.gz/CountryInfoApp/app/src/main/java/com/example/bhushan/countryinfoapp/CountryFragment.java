package com.example.bhushan.countryinfoapp;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.Button;

import java.util.ArrayList;


public class CountryFragment extends Fragment {
private AutoCompleteTextView mautoCompleteTextView;
private Button mbtnsearch;
private ArrayList<String>mArrCountriesList=new ArrayList<>();
private CountryParameters mcountryParameters;
    public CountryFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_country,container,false);
        mautoCompleteTextView=view.findViewById(R.id.textviewcountry);
        mbtnsearch=view.findViewById(R.id.btncountrysearch);
        mArrCountriesList.add("Germany");
        mArrCountriesList.add("France");
        mArrCountriesList.add("Poland");
        mArrCountriesList.add("Czech Republic");
        mArrCountriesList.add("Portugal");
        mArrCountriesList.add("Spain");
        mArrCountriesList.add("Belgium");
        mArrCountriesList.add("Great Britain");
        mArrCountriesList.add("Italy");
        mArrCountriesList.add("Greece");
        mArrCountriesList.add("Croatia");
        mArrCountriesList.add("Switzerland");
        mArrCountriesList.add("Netherlands");


        mbtnsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              Bundle bundle=getArguments();
              mcountryParameters= (CountryParameters) bundle.getSerializable("country");
            }
        });

        return view;
    }
}
