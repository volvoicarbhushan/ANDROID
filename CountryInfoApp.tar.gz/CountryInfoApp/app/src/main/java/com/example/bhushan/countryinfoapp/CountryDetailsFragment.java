package com.example.bhushan.countryinfoapp;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class CountryDetailsFragment extends Fragment {
private RecyclerView mrecyclerv;
private AdapterDetailFragments adapterDetailFragments;
private RequestQueue requestQueue;
private Context mcontext;
private ArrayList<CountryParameters>mArrCountriesList=new ArrayList<>();
String url="https://restcountries.eu/rest/v2/name/france";


    public CountryDetailsFragment() {

    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_country_details,container,false);
        mrecyclerv=view.findViewById(R.id.recylercountrydetails);
        requestQueue= Volley.newRequestQueue(mcontext);

        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                for (int i=0; i<= response.length(); i++){
                    try {
                        JSONObject jsonObject = response.getJSONObject(i);
                        String countryname = jsonObject.getString("companyname");
                        JSONObject user = jsonObject.getJSONObject("user");
                        String capital = user.getString("capital");
                        String language = jsonObject.getString("language");
                        int population = jsonObject.getInt("population");
                        int timezone = jsonObject.getInt("timezone");
                        String borderingcountries = jsonObject.getString("body");
                        int currencycode=jsonObject.getInt("currencycode");
                        CountryParameters countryParameters = new CountryParameters(countryname,capital,language,borderingcountries,population,timezone,currencycode);
                        mArrCountriesList.add(countryParameters);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("error",error.toString());
            }
        });
        requestQueue.add(jsonArrayRequest);
        adapterDetailFragments = new AdapterDetailFragments(mcontext, mArrCountriesList);
        mrecyclerv.setAdapter(adapterDetailFragments);
        adapterDetailFragments.notifyDataSetChanged();

        return view;
}
}
