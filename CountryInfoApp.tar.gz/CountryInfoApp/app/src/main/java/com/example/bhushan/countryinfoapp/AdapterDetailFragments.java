package com.example.bhushan.countryinfoapp;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by bhushan on 4/11/17.
 */

public class AdapterDetailFragments extends RecyclerView.Adapter<AdapterDetailFragments.ViewHolderCountry> {
   private Context mcontext;
   private ArrayList<CountryParameters>mArrCountriesList;

    public AdapterDetailFragments(Context context, ArrayList<CountryParameters> ArrCountriesList) {
        this.mcontext = context;
        this.mArrCountriesList = ArrCountriesList;
    }

    @Override
    public ViewHolderCountry onCreateViewHolder(ViewGroup parent, int viewType) {
       // LayoutInflater layoutInflater=LayoutInflater.from(mcontext);
        View view=LayoutInflater.from(mcontext).inflate(R.layout.lay_country_details,null);
        ViewHolderCountry viewHolderCountry=new ViewHolderCountry(view);
        return viewHolderCountry;
    }

    @Override
    public void onBindViewHolder(ViewHolderCountry holder, int position) {
final CountryParameters countryParameters=mArrCountriesList.get(position);
        holder.mcountryname.setText("countryname: "+countryParameters.getCountryname());
        holder.capital.setText("capital: "+countryParameters.getCapital());
        holder.population.setText("population: "+countryParameters.getPopulation());
        holder.language.setText("language: "+countryParameters.getLanguage());
        holder.currencycode.setText("currencycode: "+countryParameters.getCurrencycode());
        holder.timezone.setText("timezone: "+countryParameters.getTimezone());
        holder.borderingcountries.setText("borderingcountries: "+countryParameters.getBorderingcountries());
    }

    @Override
    public int getItemCount() {
        if (mArrCountriesList==null){
        return 0;
    }else
        return mArrCountriesList.size();
    }

    public class ViewHolderCountry extends RecyclerView.ViewHolder {
        TextView mcountryname,capital,population,language,currencycode,timezone,borderingcountries;

        public ViewHolderCountry(View itemView) {
            super(itemView);
            mcountryname=itemView.findViewById(R.id.textviewcountry);
            capital=itemView.findViewById(R.id.textviewcountry);
            population=itemView.findViewById(R.id.textviewcountry);
            language=itemView.findViewById(R.id.textviewcountry);
            currencycode=itemView.findViewById(R.id.textviewcountry);
            timezone=itemView.findViewById(R.id.textviewcountry);
            borderingcountries=itemView.findViewById(R.id.textviewcountry);
        }
    }
}
